"""
Reference:
This project was done by completing the tutorial of Jose Portilla Flask Bootcamp(udemy). I have used the very similiar ideas, format, and code structure used in his tutorial to work on my project.

"""

from PetBook import db,login_manager
from datetime import datetime
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import UserMixin

# The user_loader decorator allows flask-login to load the current user
# and grab their id.

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)

# Table for following users(many-to-many relationship)
following = db.Table('following',
    db.Column('follower_id', db.Integer, db.ForeignKey('users.id')),
    db.Column('followed_id', db.Integer, db.ForeignKey('users.id')))

class User(db.Model, UserMixin):
    #User Account Model

    # Create a table in the db
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key = True)
    profile_image = db.Column(db.String(20), nullable=False, default='default_profile.png')
    email = db.Column(db.String(64), unique=True, index=True)
    username = db.Column(db.String(64), unique=True, index=True)
    password_hash = db.Column(db.String(128))    

    # This connects PetPosts to a User Author.
    posts = db.relationship('PetPost', backref='author', lazy=True)
    
    # Create a many-to-many relationship between users with following table
    # https://docs.sqlalchemy.org/en/14/orm/relationship_api.html
    followed = db.relationship('User', secondary = following,
        primaryjoin = (following.c.follower_id == id),  # Link follower_id with 'following'
        secondaryjoin = (following.c.followed_id == id),# Link followed_id with 'following'
        backref = db.backref('following', lazy = 'dynamic'), lazy = 'dynamic')  # access both sides of relationship
    
    def __init__(self, email, username, password):
        self.email = email
        self.username = username
        self.password_hash = generate_password_hash(password)

    def check_password(self,password):
        # https://stackoverflow.com/questions/23432478/flask-generate-password-hash-not-constant-output
        return check_password_hash(self.password_hash,password)

    def __repr__(self):
        return f"UserName: {self.username}"
    
    # Add the user to the followed users
    def follow(self, user):
        if not self.is_following(user):
            self.followed.append(user)
    
    # Remove the user from the followed users
    def unfollow(self, user):
        if self.is_following(user):
            self.followed.remove(user)
    
    # Checks if the user is already a follower
    def is_following(self, user):
        return self.followed.filter(following.c.followed_id == user.id).count() > 0
    
    def following_posts(self):
        # Collect the posts by followed users
        followed = PetPost.query.join(
            following, following.c.followed_id == PetPost.user_id)).filter(
                following.c.follower_id == self.id)
        # Collect the posts by yourself
        own = PetPost.query.filter_by(user_id = self.id)
        # Join both sets of posts
        return followed.union(own).order_by(PetPost.date.desc())

class PetPost(db.Model):
    # Setup the relationship to the User table
    users = db.relationship(User)

    # Model for the Pet Posts on Website
    id = db.Column(db.Integer, primary_key=True)
    # Notice how we connect the PetPost to a particular author
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    title = db.Column(db.String(140), nullable=False)
    text = db.Column(db.Text, nullable=False)


    def __init__(self, title, text, user_id):
        self.title = title
        self.text = text
        self.user_id =user_id


    def __repr__(self):
        return f"Post Id: {self.id} --- Date: {self.date} --- Title: {self.title}"
